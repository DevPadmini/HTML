#include<stdio.h>
int main(){
    //Assign
    int number = 10;
    printf("hellow world\n");

    printf("%d \n", number);

    //Input
    int input ;
    printf("Enter a number; ");
    scanf("%d", &input);

    //Output
    printf("%d", input);

    return 0;

}